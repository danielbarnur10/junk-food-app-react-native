import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { orderService } from "@/services/order.service";
import { Order } from "@/types/orders";

const ORDER_KEY = ["order"];

export const useOrder = () =>
  useQuery<Order>({
    queryKey: ORDER_KEY,
    queryFn: orderService.get,
  });

type AddOrderVars = void | {
  productId?: string;
  qty?: number;
  quantity?: number;
};

export const useAddOrder = () => {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (vars?: AddOrderVars) => {
      const v = vars as any;
      if (v && v.productId) {
        const q =
          typeof v.qty === "number"
            ? v.qty
            : typeof v.quantity === "number"
            ? v.quantity
            : 1;
        return orderService.addItem(v.productId, q);
      }
      return orderService.finalize();
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ORDER_KEY }),
  });
};

export const useUpdateOrderItem = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (vars: {
      productId: string;
      qty?: number;
      quantity?: number;
    }) => {
      const q =
        typeof vars.qty === "number"
          ? vars.qty
          : typeof vars.quantity === "number"
          ? vars.quantity
          : 1;
      return orderService.updateItem(vars.productId, q);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ORDER_KEY }),
  });
};

export const useRemoveOrderItem = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (productId: string) => orderService.removeItem(productId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ORDER_KEY }),
  });
};

export const useClearOrder = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => orderService.clear(),
    onSuccess: () => qc.invalidateQueries({ queryKey: ORDER_KEY }),
  });
};
