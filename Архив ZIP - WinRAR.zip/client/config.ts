// src/config.ts
import { Platform } from "react-native";
import Constants from "expo-constants";

function ensureApiSuffix(url: string) {
  const cleaned = url.replace(/\/+$/, "");
  return cleaned.endsWith("/api") ? cleaned : `${cleaned}/api`;
}

function resolveDevBase(): string {
  const env = process.env.EXPO_PUBLIC_API_BASE_URL;
  if (env) {
    const withApi = ensureApiSuffix(env);
    console.debug("[config] API from ENV:", withApi);
    return withApi;
  }

  const hostUri =
    (Constants as any)?.expoConfig?.hostUri ||
    (Constants as any)?.manifest?.debuggerHost ||
    (Constants as any)?.manifest2?.extra?.expoClient?.hostUri;

  if (hostUri) {
    const host = hostUri.split(":")[0];
    const port = "3001";
    const url = `http://${host}:${port}/api`;
    console.debug("[config] API from Expo hostUri:", url);
    return url;
  }

  if (Platform.OS === "android") {
    const url = "http://10.0.2.2:3001/api";
    console.debug("[config] API fallback (Android emulator):", url);
    return url;
  }

  const fallback = "http://192.168.1.100:3001/api";
  console.debug("[config] API fallback (manual IP):", fallback);
  return fallback;
}

const isDev = process.env.NODE_ENV === "development";

export const API_URL = isDev
  ? resolveDevBase()
  : "https://your-production-domain.com/api";
