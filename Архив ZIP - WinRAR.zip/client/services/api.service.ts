import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { API_URL } from "@/config";

async function readTokenFlexible(): Promise<string | null> {
  const keys = ["authToken", "token", "accessToken", "jwt"];
  for (const k of keys) {
    const v = await AsyncStorage.getItem(k);
    if (v) return v.replace(/^"|"$/g, "");
  }
  const rawUser = await AsyncStorage.getItem("user");
  if (rawUser) {
    try {
      const u = JSON.parse(rawUser);
      return u?.token || u?.jwt || null;
    } catch {}
  }
  return null;
}

export const api = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use(async (config: any) => {
  const token = await readTokenFlexible();
  if (token && config.headers) {
    config.headers.authorization = `Bearer ${token}`;
  }
  return config;
});
