/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/../hooks/useCart`; params?: Router.UnknownInputParams; } | { pathname: `/../1/services/order.service`; params?: Router.UnknownInputParams; } | { pathname: `/../1/services/product.service`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/../hooks/useCart`; params?: Router.UnknownOutputParams; } | { pathname: `/../1/services/order.service`; params?: Router.UnknownOutputParams; } | { pathname: `/../1/services/product.service`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/../hooks/useCart${`?${string}` | `#${string}` | ''}` | `/../1/services/order.service${`?${string}` | `#${string}` | ''}` | `/../1/services/product.service${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/../hooks/useCart`; params?: Router.UnknownInputParams; } | { pathname: `/../1/services/order.service`; params?: Router.UnknownInputParams; } | { pathname: `/../1/services/product.service`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
    }
  }
}
