import { Request, Response, NextFunction } from "express";
import { Types } from "mongoose";
import {
  addItem,
  updateItem as svcUpdateItem,
  removeItem as svcRemoveItem,
  clearCart,
  getOrCreateCart,
} from "../services/cart.service";
import Product from "../models/ProductModel";
import { Order } from "../models/Order";

function requireUserId(req: Request, res: Response): Types.ObjectId | null {
  // из JWT (authGuard)
  if (req.user?.id) return new Types.ObjectId(req.user.id);
  const headerId = req.headers["x-user-id"];
  if (headerId) return new Types.ObjectId(String(headerId));
  res.status(401).json({ success: false, message: "User not authenticated" });
  return null;
}

type HydratedCartItem = {
  product: any;
  quantity: number;
  price: number;
};

type HydratedCartAsOrderLike = {
  _id: string;
  user: string;
  items: HydratedCartItem[];
  total: number;
  status: "pending";
  createdAt: Date;
  updatedAt: Date;
};

async function hydrateCartAsOrderLike(
  userId: Types.ObjectId
): Promise<HydratedCartAsOrderLike> {
  const cart = await getOrCreateCart(userId);

  const ids = cart.items.map((i) => i.productId);
  const products = await Product.find({ _id: { $in: ids } }).lean();
  const map = new Map(products.map((p) => [String(p._id), p]));

  const items: HydratedCartItem[] = [];
  let total = 0;

  for (const i of cart.items) {
    const product = map.get(String(i.productId));
    if (!product) continue;
    const price = Number(product.price ?? 0);
    total += price * i.qty;
    items.push({ product, quantity: i.qty, price });
  }

  return {
    _id: String(cart._id),
    user: String(userId),
    items,
    total,
    status: "pending",
    createdAt: cart.createdAt,
    updatedAt: cart.updatedAt,
  };
}

export const orderCartController = {
  getCart: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;
      const data = await hydrateCartAsOrderLike(userId);
      return res.json({ success: true, message: "Cart fetched", data });
    } catch (e) {
      next(e);
    }
  },

  addItem: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;

      const rawProductId = req.body?.productId || req.body?.id;
      const qtyRaw = req.body?.qty ?? req.body?.quantity ?? 1;
      const qty = Number(qtyRaw);

      if (
        !rawProductId ||
        !Types.ObjectId.isValid(String(rawProductId)) ||
        !Number.isFinite(qty) ||
        qty <= 0
      ) {
        return res.status(400).json({
          success: false,
          message: "Valid productId and positive qty/quantity are required",
        });
      }

      const prod = await Product.findById(rawProductId).select("_id");
      if (!prod)
        return res
          .status(404)
          .json({ success: false, message: "Product not found" });

      await addItem(userId, new Types.ObjectId(String(rawProductId)), qty);
      const data = await hydrateCartAsOrderLike(userId);
      return res.json({ success: true, message: "Item added to cart", data });
    } catch (e) {
      next(e);
    }
  },

  updateItem: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;

      const { productId } = req.params;
      const qtyRaw = req.body?.qty ?? req.body?.quantity;
      const qty = Number(qtyRaw);

      if (
        !productId ||
        !Types.ObjectId.isValid(productId) ||
        !Number.isFinite(qty)
      ) {
        return res.status(400).json({
          success: false,
          message: "Valid :productId and numeric qty/quantity are required",
        });
      }

      await svcUpdateItem(userId, new Types.ObjectId(productId), qty);
      const data = await hydrateCartAsOrderLike(userId);
      return res.json({ success: true, message: "Cart item updated", data });
    } catch (e) {
      next(e);
    }
  },

  removeItem: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;

      const { productId } = req.params;
      if (!productId || !Types.ObjectId.isValid(productId)) {
        return res
          .status(400)
          .json({ success: false, message: "Valid :productId is required" });
      }

      await svcRemoveItem(userId, new Types.ObjectId(productId));
      const data = await hydrateCartAsOrderLike(userId);
      return res.json({ success: true, message: "Cart item removed", data });
    } catch (e) {
      next(e);
    }
  },

  clear: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;

      await clearCart(userId);
      const data = await hydrateCartAsOrderLike(userId);
      return res.json({ success: true, message: "Cart cleared", data });
    } catch (e) {
      next(e);
    }
  },

  createOrder: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;

      const cartLike = await hydrateCartAsOrderLike(userId);
      if (!cartLike.items.length) {
        return res.status(409).json({
          success: false,
          message:
            "Cart is empty or contains unavailable products. Please refresh your cart.",
        });
      }

      const orderItems = cartLike.items.map((i) => ({
        productId: i.product._id,
        qty: i.quantity,
        priceAtPurchase: i.price,
      }));

      const order = await Order.create({
        userId,
        items: orderItems,
        total: cartLike.total,
        status: "placed",
      });

      await clearCart(userId);
      return res
        .status(201)
        .json({ success: true, message: "Order created", data: { order } });
    } catch (e) {
      next(e);
    }
  },

  listOrders: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = requireUserId(req, res);
      if (!userId) return;

      const orders = await Order.find({ userId }).sort({ createdAt: -1 });
      return res.json({
        success: true,
        message: "Orders list",
        data: { orders },
      });
    } catch (e) {
      next(e);
    }
  },
};
