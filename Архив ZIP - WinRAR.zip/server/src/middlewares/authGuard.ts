import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

type JwtPayload = { id: string };

declare global {
  namespace Express {
    interface Request {
      user?: { id: string };
    }
  }
}

export function authGuard(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;

  if (!authHeader && process.env.NODE_ENV !== "production") {
    const devUserId = req.headers["x-user-id"];
    if (devUserId) {
      req.user = { id: String(devUserId) };
      return next();
    }
  }

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res
      .status(401)
      .json({ success: false, message: "No token provided" });
  }

  try {
    const token = authHeader.split(" ")[1];
    const secret = process.env.JWT_SECRET_KEY || "secret";
    const decoded = jwt.verify(token, secret) as JwtPayload;
    req.user = { id: decoded.id };
    next();
  } catch {
    return res
      .status(401)
      .json({ success: false, message: "Invalid or expired token" });
  }
}
