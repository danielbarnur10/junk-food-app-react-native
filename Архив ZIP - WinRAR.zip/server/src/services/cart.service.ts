import { Types } from "mongoose";
import { Cart } from "../models/Cart";

export async function getOrCreateCart(userId: Types.ObjectId) {
  const found = await Cart.findOne({ userId });
  if (found) return found;
  return Cart.create({ userId, items: [] });
}

export async function addItem(
  userId: Types.ObjectId,
  productId: Types.ObjectId,
  qty: number
) {
  const cart = await getOrCreateCart(userId);
  const idx = cart.items.findIndex(
    (i) => i.productId.toString() === productId.toString()
  );
  if (idx >= 0) {
    cart.items[idx].qty += qty;
  } else {
    cart.items.push({ productId, qty });
  }
  await cart.save();
  return cart;
}

export async function updateItem(
  userId: Types.ObjectId,
  productId: Types.ObjectId,
  qty: number
) {
  const cart = await getOrCreateCart(userId);
  const idx = cart.items.findIndex(
    (i) => i.productId.toString() === productId.toString()
  );
  if (idx < 0) return cart;
  if (qty <= 0) cart.items.splice(idx, 1);
  else cart.items[idx].qty = qty;
  await cart.save();
  return cart;
}

export async function removeItem(
  userId: Types.ObjectId,
  productId: Types.ObjectId
) {
  const cart = await getOrCreateCart(userId);
  cart.items = cart.items.filter(
    (i) => i.productId.toString() !== productId.toString()
  );
  await cart.save();
  return cart;
}

export async function clearCart(userId: Types.ObjectId) {
  const cart = await getOrCreateCart(userId);
  cart.items = [];
  await cart.save();
  return cart;
}
